# pysam versioning information

__version__ = "0.7.7"

__samtools_version__ = "0.1.19"

__tabix_version__ = "0.2.6"
